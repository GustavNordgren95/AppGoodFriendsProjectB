﻿using System;
namespace Models.DTO
{
	public class usrInfoDto
	{
		public int NrUsers { get; set; }
        public int NrSuperUsers { get; set; }
    }
}

