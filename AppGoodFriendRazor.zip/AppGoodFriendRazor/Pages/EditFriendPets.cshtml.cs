// Pages/EditFriendPets.cshtml.cs

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AppGoodFriends.Pages;
using System.Collections.Generic;
using System.Linq;
using Models;

namespace AppGoodFriends.Pages
{
    public class EditFriendPetsModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public EditFriendPetsModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Pet Pet { get; set; }

        // List of friends for dropdown
        public List<Friend> Friends { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id, int? friendId)
        {
            Friends = await _context.Friends.ToListAsync();

            if (id.HasValue)
            {
                // Editing existing pet
                Pet = await _context.Pets.FirstOrDefaultAsync(m => m.Id == id);

                if (Pet == null)
                {
                    return NotFound();
                }
            }
            else
            {
                // Adding new pet
                Pet = new Pet { FriendId = friendId ?? 0 };
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                Friends = await _context.Friends.ToListAsync(); // Reload friends for dropdown
                return Page();
            }

            if (Pet.Id == 0)
            {
                _context.Pets.Add(Pet);
            }
            else
            {
                _context.Attach(Pet).State = EntityState.Modified;
            }

            await _context.SaveChangesAsync();
            return RedirectToPage("./Index"); // Redirect to an appropriate page
        }
    }
}

