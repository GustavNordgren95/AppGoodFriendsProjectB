﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Services;
using Models.DTO;

namespace AppGoodFriendRazor.Pages
{
    public class IndexModel : PageModel
    {
        


    }

   

}