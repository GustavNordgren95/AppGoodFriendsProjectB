using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppGoodFriendRazor.Pages
{
    public class EditFriendQuotesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
