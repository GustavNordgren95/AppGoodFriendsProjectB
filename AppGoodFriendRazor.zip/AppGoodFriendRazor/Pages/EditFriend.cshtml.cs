using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Services;
using Models.DTO;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;
using static AppGoodFriendRazor.Pages.EditFriendModel;
using System.ComponentModel.DataAnnotations;
using Models;
using static Npgsql.PostgresTypes.PostgresCompositeType;

namespace AppGoodFriendRazor.Pages
{
    public class EditFriendModel : PageModel
    {
        private readonly IFriendsService _friendsService;
        private readonly ILogger<ListOfFriendsModel> _logger;

        public IFriend Friend { get; set; }

        [BindProperty]
        public csFriendIM FriendInput { get; set; }

        [BindProperty]
        public csFriendIM NewFriendIM { get; set; } = new csFriendIM();

        [BindProperty]
        public string PageHeader { get; set; }

        [BindProperty(SupportsGet = true)]
        public Guid Id { get; set; }

        #region HTTP Requests
        public async Task<IActionResult> OnGetAsync()
        {
            if (Id == Guid.Empty)
            {
                return NotFound();
            }

            Friend = await _friendsService.ReadFriendAsync(null, Id, false);
            if (Friend == null)
            {
                return NotFound();
            }

            FriendInput = new csFriendIM();
            PageHeader = "Edit details of a friend";
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            try
            {
                var friendDto = new csFriendCUdto
                {
                    FriendId = FriendInput.FriendId,
                    FirstName = FriendInput.FirstName,
                    LastName = FriendInput.LastName,
                    Birthday = FriendInput.Birthday,
                    Email = FriendInput.Email
                };

                await _friendsService.UpdateFriendAsync(null, friendDto);

                return RedirectToPage("FriendDetails", new { id = friendDto.FriendId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating friend details");
                ModelState.AddModelError(string.Empty, "An error occurred while updating the friend's details.");
                return Page();
            }
        }

        #endregion

        #region Input Model
        public enum enStatusIM { Unknown, Unchanged, Inserted, Modified, Deleted }

        public class csFriendIM
        {
            public enStatusIM StatusIM { get; set; }

            public Guid FriendId { get; set; } = Guid.NewGuid();
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public DateTime? Birthday { get; set; }
            public string Email { get; set; }

            public string editFirstName { get; set; }
            public string editLastName { get; set; }
            public DateTime? editBirthday { get; set; }
            public string editEmail { get; set; }

            #region constructors and model update
            public csFriendIM() { StatusIM = enStatusIM.Unchanged; }


            public csFriendIM(csFriendIM original)
            {
                StatusIM = original.StatusIM;

                FriendId = original.FriendId;
                FirstName = original.FirstName;
                LastName = original.LastName;
                Birthday = original.Birthday;
                Email = original.Email;

                editFirstName = original.editFirstName;
                editLastName = original.editLastName;
                editBirthday = original.editBirthday;
                editEmail = original.editEmail;
            }

            public csFriendIM(csFriend original)
            {
                StatusIM = enStatusIM.Unchanged;
                FriendId = original.FriendId;
                FirstName = editFirstName = original.FirstName;
                LastName = editLastName = original.LastName;
                Birthday = editBirthday = original.Birthday;
                Email = editEmail = original.Email;
            }

            public csFriend UpdateModel(csFriend model)
            {
                model.FriendId = FriendId;
                model.FirstName = FirstName;
                model.LastName = LastName;
                model.Birthday = Birthday;
                model.Email = Email;
                return model;
            }
            #endregion

        }
        #endregion
    }
}

